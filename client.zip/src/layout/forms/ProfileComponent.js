import React, {Component} from 'react';
import ProfileSchema from "./schemaValidation/ProfileSchemaValidation";
import {faUserEdit} from "@fortawesome/free-solid-svg-icons";
import UserInput from "../UI/UserInputComponent";
import Avatar from "../UI/AvatarComponent";
import {Form, Formik} from "formik";
import SubmitButton from "../UI/SubmitButtonComponent";
import PropTypes from "prop-types";
import {connect} from "react-redux";
import {updateUser, getUser} from "../../actions/authActions";
import {withRouter} from "react-router-dom";

class Profile extends Component {
    constructor(props) {
        super(props);
        this.state = {
            user: [],
        };
    }

   /* componentDidMount() {
        this.props.getUser();
        console.log()
    }*/

    UNSAFE_componentWillReceiveProps(nextProps) {
        if (nextProps.errors) {
            this.setState({
                errors: nextProps.errors
            });
        }
    }

    onSubmit = (message) => {
        this.setState({user: message});
        console.log(this.state.user);
        this.props.updateUser(message);
    };

    render() {
        return (
            <div className="center-block">
                <Avatar icon={faUserEdit}/>
                <Formik
                    validationSchema={ProfileSchema}
                    validateOnChange={false}
                    onSubmit={this.onSubmit}
                    initialValues={{}}>

                    <Form className="form-container form-control login-form col-md-6 col-lg-5">
                        <span className="row justify-content-center"><h2 className="login-h2">Personal data</h2></span>

                        <UserInput type={"text"} placeholder={"Name"} name="name"/>
                        <UserInput type={"number"} placeholder={"Age"} name="age"/>

                        <div className="row justify-content-center radio-check">
                            <div className="form-check  form-check-inline">
                                <input type="radio" className="form-check-input" name="gender" id="Not-Specified"
                                       defaultChecked={true}/>
                                <label className="form-check-label" htmlFor="Not-Specified">Not Specified</label>
                            </div>
                            <div className="form-check  form-check-inline">
                                <input type="radio" className="form-check-input" id="Female" name="gender"/>
                                <label className="form-check-label" htmlFor="Female">Female</label>
                            </div>
                            <div className="form-check  form-check-inline">
                                <input type="radio" className="form-check-input" name="gender" id="Male"/>
                                <label className="form-check-label" htmlFor="Male">Male</label>
                            </div>
                        </div>

                        <hr/>
                        <UserInput type={"password"} placeholder={"Password"} name="password"/>
                        <UserInput type={"password"} placeholder={"New password"} name="new_password"/>
                        <SubmitButton buttonText={"Edit"}/>
                    </Form>
                </Formik>
            </div>
        )
    }
}

Profile.propTypes = {
    updateUser: PropTypes.func.isRequired,
    //getUser: PropTypes.func.isRequired,
    auth: PropTypes.object.isRequired,
    errors: PropTypes.object.isRequired
};
const mapStateToProps = state => ({
    auth: state.auth,
    errors: state.errors
});
export default connect(
    mapStateToProps,
    {updateUser},
    //{getUser}
)(withRouter(Profile));