import React, {Component} from 'react';
import '../App.css';

class NotFound extends Component {
    render() {
        return (
            <div className="App">
                <span className="row justify-content-center"><h1>404 Not Found</h1></span>
            </div>
        );
    }
}

export default NotFound;