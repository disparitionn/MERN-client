import React, {Component} from 'react';
import {Field, getIn} from "formik";

class UserInput extends Component {
    constructor(props) {
        super(props);
        this.state = {
            value: ''
        };
        //this.changeValue = this.changeValue.bind(this);
    };

    getStyles = (errors, fieldName, touched) => {
        if (getIn(errors, fieldName)) {
            return {
                border: '1px solid red'
            }
        }
    };

    /*changeValue = (e) => {
        if (!e.target.value) {
            return
        }
        let val = e.target.value;
        this.setState({value: val});
        this.props.handler(val);
        //this.props.onValChange(this.props.name, val);
    };*/

  /*  UNSAFE_componentWillReceiveProps(nextProps, nextContext) {
        this.setState({value: nextProps.value})
    }
*/
    render() {
        return (
            <Field name={this.props.name}>
                   {({field, form: {touched, errors}, meta}) => (
                       <div className={"row justify-content-center"}>
                           <input {...field} className="login-input"
                                  type={this.props.type}
                                  style={this.getStyles(errors, field.name)}
                                  placeholder={this.props.placeholder}
                           />
                           {touched[field.name] &&
                           errors[field.name] &&
                           <div className="error">{errors[field.name]}</div>}
                       </div>
                   )}
            </Field>
        );
    }
}

export default UserInput;